﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data
{
    public class Repository : IRepository
    {
        private readonly BookstoreDBContext _context;

        public Repository(BookstoreDBContext context)
        {
            _context = context;
        }

        public List<T> GetAll<T>() where T : class
        {
           return _context.Set<T>().ToList();
        }

        public List<T> GetAllWith<T>(string[] includes) where T : class
        {
            var query = _context.Set<T>().AsQueryable();

            foreach (var include in includes)
            {
                query = query.Include(include);
            }

            return query.ToList();
        }

        public T? Get<T>(int id) where T : class
        {
            return _context.Set<T>().Find(id);
        }

        public T? FindOneWith<T>(Func<T, Boolean> callback, string[] includes) where T : class
        {
            var query = _context.Set<T>().AsQueryable();

            foreach (var include in includes)
            {
                query = query.Include(include);
            }

            return query.FirstOrDefault(callback!, null);
        }

        public List<T> FindAllWith<T>(Func<T, Boolean> callback, string[] includes) where T : class
        {
            var query = _context.Set<T>().AsQueryable();

            foreach (var include in includes)
            {
                query = query.Include(include);
            }

            return query.Where(callback).ToList();
        }

        public bool Add<T>(T entity) where T : class
        {
            _context.Set<T>().Add(entity);
            return _context.SaveChanges() > 0;
        }

        public bool Delete<T>(T entity) where T : class
        {
            _context.Set<T>().Remove(entity);
            return _context.SaveChanges() > 0;
        }

        public bool Update<T>(T entity) where T : class
        {
            _context.Set<T>().Update(entity);
            return _context.SaveChanges() > 0;
        }
    }
}

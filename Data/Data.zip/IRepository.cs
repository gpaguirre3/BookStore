﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data
{
    public interface IRepository
    {
        public List<T> GetAll<T>() where T : class;

        public List<T> GetAllWith<T>(string[] includes) where T : class;

        public T? Get<T>(int id) where T : class;

        public T? FindOneWith<T>(Func<T, Boolean> callback, string[] includes) where T : class;

        public List<T> FindAllWith<T>(Func<T, Boolean> callback, string[] includes) where T : class;

        public bool Add<T>(T entity) where T : class;

        public bool Update<T>(T entity) where T : class;

        public bool Delete<T>(T entity) where T : class;
    }
}
